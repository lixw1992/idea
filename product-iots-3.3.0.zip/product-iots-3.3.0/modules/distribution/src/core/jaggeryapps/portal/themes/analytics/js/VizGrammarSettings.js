var vizgSettings = {
    colorScale: colorbrewer.RdYlBu[4].reverse(),
    colors: {
        green:"#5FCE9B",
        blue:"#438CAD",
        red:"#E87352",
        yellow:"#EECA5A",
        purple:"#B6688F",
        grey:"434343",
        brown:"#C59787"
    }
}